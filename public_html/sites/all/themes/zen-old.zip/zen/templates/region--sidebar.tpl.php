<?php
?>
<?php if ($content): ?>
  <div class="<?php print $classes; ?>"><div class="section">
    <?php print $content; ?>
  </div></div><!-- /.section, /.region -->
<?php endif; ?>
